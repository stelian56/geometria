define(["dojo", "dojox/lang/functional", "dijit"], function(dojo, dlf, dijit){

	return dojo.declare("util.docscripts.tests.FunctionalThinger", null, {
		// summary:
		//		This is a test.
		constructor: function(args){
			dojo._mixin(this, args);
		}
		
	});

});