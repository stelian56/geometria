define(
({
	"previousMessage" : "Əvvəlki variantlar",
	"nextMessage" : "Başqa variantlar"
})
);
